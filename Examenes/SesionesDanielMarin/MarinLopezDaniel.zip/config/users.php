<?php
    /**
     * @author Daniel Marín López
     * @version 0.01a
     * 
     */

    define("USERS", array(
        array("user" => "Daniel",
        "passwd" => "Marin")
    ));

?>